import java.util.ArrayList;

public class Customer {

    private String username;
    private String password;
    private Integer balance = 0;
    private ArrayList<Discounts> discounts;

    private ArrayList<Cart> carts;

    public Customer(String username, String password) {

        this.username = username;
        this.password = password;
        this.carts = new ArrayList<>();
        this.discounts = new ArrayList<>();
    }

    public void setBalance(Integer balance) {
        this.balance += balance;
    }
    public int getBalance(){
        return balance;
    }
    public void addCart(Cart cart){
        carts.add(cart);
    }

    public String getUsername() {
        return username;
    }

    public void setName(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    public ArrayList<Discounts> getDiscounts(){
        return discounts;
    }

    public Cart getFoodFromCartByName(String name){
        for (Cart temp : carts){
            if (temp.getName().equals(name)) return temp;
        }
        return null;
    }
    public ArrayList<Cart> getCarts(){
        return carts;
    }
    public Discounts getDiscountByCode(String code){
        for (Discounts temp : discounts) {
            if(temp.getCode().equals(code)) return temp;
        }
        return null;
    }

    public Cart getCartByName(String name){
        for (Cart temp : carts) {
            if (temp.getName().equals(name)) return temp;
        }
        return null;
    }

    public int  removeWithIndex(String name) {
        for (int i = 0; i < discounts.size(); i++) {
            if (discounts.get(i).getCode().equals(name)) return i;
        }
        return -1;
    }

}
