import java.util.ArrayList;

public class Restaurant {
   private String name;
   private Integer balance;
   private String type;
   private String password;
   private ArrayList<Food> foods ;
    public Restaurant(String name, String type, String password) {
        this.name = name;
        this.balance = 0;
        this.type = type;
        this.password = password;
        this.foods = new ArrayList<>();
    }
    public ArrayList<Food> getFoods(){
        return foods;
    }
    public Food getFoodByName(String name){
        for (Food temp : foods) {
            if(temp.getName().equals(name)) return temp;
        }
        return null;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getBalance() {
        return balance;
    }

    public void setBalance(Integer amount) {
        this.balance += amount;
    }

    public String getType() {
        return type;
    }


    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
