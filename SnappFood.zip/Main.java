public class Main {
    public static void main(String[] args) {
        String adminUsername, adminPassword;

        adminUsername = LoginMenu.getScanner().nextLine();
        adminPassword = LoginMenu.getScanner().nextLine();
        Customer snappAdmin = new Customer(adminUsername, adminPassword);

        LoginMenu loginMenu = new LoginMenu();
        AllUsersInfo.getCustomers().add(snappAdmin);
        loginMenu.run(LoginMenu.getScanner());

    }

    }
