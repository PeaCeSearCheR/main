import java.util.Scanner;
import java.util.regex.Matcher;

public class MainMenu {
    public void run(Scanner scanner) {
        Matcher matcher;
        String command;
        while (true) {

            command = scanner.nextLine();


            if (command.matches("^\\s*logout\\s*$")) {
                LoginMenu loginMenu = new LoginMenu();
                loginMenu.run(scanner);
            } else if ((matcher = Commands.getMatcher("^\\s*enter\\s+.+", command)) != null){
                if ((matcher = Commands.getMatcher("^\\s*enter\\s+(?<menuname>customer menu|restaurant admin menu|Snappfood admin menu)\\s*$",command)) != null)
                enterMenus(matcher);
                else System.out.println("enter menu failed: invalid menu name");
            }


            else if ((matcher = Commands.getMatcher("^\\s*show\\s+current\\s+menu\\s*$", command)) != null) {
                System.out.println("main menu");
            } else System.out.println("invalid command!");

        }
    }


    public static void enterMenus(Matcher matcher) {

        String menuName = matcher.group("menuname").replaceAll("\\s+"," ");
        switch (menuName) {
            case "customer menu":

                if((AllUsersInfo.getRestaurantByUsername(AllUsersInfo.getCurrentCustomer().getUsername()) != null) ||
                        (AllUsersInfo.getCurrentCustomer().equals(AllUsersInfo.getCustomers().get(0)))) {
                    System.out.println("enter menu failed: access denied");
                    return;
                }

                System.out.println("enter menu successful: You are in the customer menu!");
                CustomerMenu customerMenu = new CustomerMenu();
                customerMenu.run(LoginMenu.getScanner());
                return;

            case "restaurant admin menu":

                if((AllUsersInfo.getCurrentCustomer().equals(AllUsersInfo.getCustomers().get(0))) ||
                        (AllUsersInfo.getRestaurantByUsername(AllUsersInfo.getCurrentCustomer().getUsername())) ==null) {
                    System.out.println("enter menu failed: access denied");
                    return;
                }

                System.out.println("enter menu successful: You are in the restaurant admin menu!");
                RestaurantAdminMenu restaurantAdminMenu = new RestaurantAdminMenu();
                restaurantAdminMenu.run(LoginMenu.getScanner());
                return;

            case "Snappfood admin menu":

                if(!AllUsersInfo.getCurrentCustomer().equals(AllUsersInfo.getCustomers().get(0))){
                    System.out.println("enter menu failed: access denied");
                    return;
                }

                System.out.println("enter menu successful: You are in the Snappfood admin menu!");
                SnappfoodAdminMenu snappfoodAdminMenu = new SnappfoodAdminMenu();
                snappfoodAdminMenu.run(LoginMenu.getScanner());
                return;

            default:
                System.out.println("enter menu failed: invalid menu name");


        }

    }
}
