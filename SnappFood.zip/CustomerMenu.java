import java.util.Objects;
import java.util.Scanner;
import java.util.regex.Matcher;

public class CustomerMenu {
    Customer customer = AllUsersInfo.getCurrentCustomer();


    public void run(Scanner scanner) {
        String command;
        Matcher matcher;
        while (true) {
            command = scanner.nextLine();

            if (command.matches("^\\s*logout\\s*$")) {
                LoginMenu loginMenu = new LoginMenu();
                loginMenu.run(LoginMenu.getScanner());
            } else if ((matcher = Commands.getMatcher("^\\s*charge\\s+account\\s+(?<amount>\\S+)\\s*$", command)) != null)
                System.out.println(chargeCustomer(matcher));
            else if ((matcher = Commands.getMatcher("^\\s*show\\s+balance\\s*$", command)) != null)
                System.out.println(showBalance());
            else if ((matcher = Commands.getMatcher("^\\s*show\\s+restaurant(\\s+-t\\s+(?<type>\\S+))?\\s*$", command)) != null)
                System.out.print(showRestaurants(matcher));
            else if ((matcher = Commands.getMatcher("^\\s*show\\s+menu\\s+(?<name>\\S+)(\\s+-c\\s+(?<category>\\S+))?\\s*$", command)) != null)
                System.out.print(showMenu(matcher));
            else if ((matcher = Commands.getMatcher("^\\s*add\\s+to\\s+cart\\s+(?<restaurantname>\\S+)\\s+(?<foodname>\\S+)(\\s+-n\\s+(?<number>\\S+))?\\s*$", command)) != null)
                System.out.println(addToCart(matcher));
            else if ((matcher = Commands.getMatcher("^\\s*remove\\s+from\\s+cart\\s+(?<restaurantname>\\S+)\\s+(?<foodname>\\S+)(\\s+-n\\s+(?<number>\\S+))?\\s*$", command)) != null)
                System.out.println(removeFromCard(matcher));
            else if ((matcher = Commands.getMatcher("^\\s*show\\s+current\\s+menu\\s*$", command)) != null)
                System.out.print("customer menu");
            else if ((matcher = Commands.getMatcher("^\\s*show\\s+discounts\\s*$", command)) != null)
                System.out.print(showDiscounts());
            else if ((matcher = Commands.getMatcher("^\\s*show\\s+cart\\s*$", command)) != null)
                System.out.print(showCart());
            else if ((matcher = Commands.getMatcher("^\\s*purchase\\s+cart(\\s+-d\\s+(?<discount>\\S+))?\\s*$", command)) != null)
                System.out.println(payTheCart(matcher));
            else System.out.println("invalid command!");

        }

    }

    public String chargeCustomer(Matcher matcher) {

        int amount = Integer.parseInt(matcher.group("amount"));
        if (amount <= 0) return "charge account failed: invalid cost or price";
        customer.setBalance(amount);
        return "charge account successful";
    }

    public int showBalance() {
        return customer.getBalance();
    }

    public String showRestaurants(Matcher matcher) {
        String result = "";
        int counter = 1;

        if (matcher.group("type") != null) {
            String type = matcher.group("type");
            for (Restaurant temp : AllUsersInfo.getRestaurants()) {
                if (temp.getType().equals(type)) {
                    result += counter + ") " + temp.getName() + ": type=" + temp.getType() + "\n";
                    counter++;
                }
            }
            return result;
        } else {
            for (Restaurant temp : AllUsersInfo.getRestaurants()) {
                result += counter + ") " + temp.getName() + ": type=" + temp.getType() + "\n";
                counter++;
            }
            return result;
        }
    }

    public String showMenu(Matcher matcher) {
        String starter = "", entree = "", dessert = "";

        String name = matcher.group("name");
        Restaurant restaurant = AllUsersInfo.getRestaurantByUsername(name);

        if (restaurant == null) return "show menu failed: restaurant not found\n";


        if (matcher.group("category") == null) {
            starter = "<< STARTER >>\n";
            entree = "<< ENTREE >>\n";
            dessert = "<< DESSERT >>\n";
            for (Food temp : restaurant.getFoods()) {
                if (temp.getCategory().equals("starter"))
                    starter += temp.getName() + " | price=" + temp.getPrice() + "\n";
                else if (temp.getCategory().equals("entree")) {
                    entree += temp.getName() + " | price=" + temp.getPrice() + "\n";
                } else if (temp.getCategory().equals("dessert")) {
                    dessert += temp.getName() + " | price=" + temp.getPrice() + "\n";
                }
            }

            return starter + entree + dessert;

        } else {
            String category = matcher.group("category");
            if (!category.matches("(dessert|entree|starter)")) return "show menu failed: invalid category\n";
            if (category.equals("starter")) {
                for (Food temp : restaurant.getFoods()) {
                    if (temp.getCategory().equals("starter")) {
                        starter += temp.getName() + " | price=" + temp.getPrice() + "\n";
                    }
                }
                return starter;

            } else if (category.equals("entree")) {
                for (Food temp : restaurant.getFoods()) {
                    if (temp.getCategory().equals("entree")) {
                        entree += temp.getName() + " | price=" + temp.getPrice() + "\n";
                    }
                }
                return entree;

            } else if (category.equals("dessert")) {
                for (Food temp : restaurant.getFoods()) {
                    if (temp.getCategory().equals("dessert")) {
                        dessert += temp.getName() + " | price=" + temp.getPrice() + "\n";
                    }
                }
                return dessert;
            }
        }
        return "";
    }

    public String addToCart(Matcher matcher) {
        Cart cart;
        String restaurantName = matcher.group("restaurantname");
        String foodName = matcher.group("foodname");
        Restaurant restaurant = AllUsersInfo.getRestaurantByUsername(restaurantName);
        if (restaurant == null) return "add to cart failed: restaurant not found";
        Food food = restaurant.getFoodByName(foodName);

        if (food == null) return "add to cart failed: food not found";

        if (matcher.group("number") == null) {
            if (((cart = customer.getCartByName(foodName)) != null) && cart.getRestaurant().equals(restaurantName)) {
                cart.setNumber(1);
                return "add to cart successful";
            }
            customer.addCart(new Cart(1, food.getPrice(), food.getName(), food.getRestaurant()));
            return "add to cart successful";

        } else {
            if (Integer.parseInt(matcher.group("number")) <= 0) return "add to cart failed: invalid number";
            int number = Integer.parseInt(matcher.group("number"));
            if (((cart = customer.getCartByName(foodName)) != null) && cart.getRestaurant().equals(restaurantName)) {
                cart.setNumber(number);
                return "add to cart successful";
            }
            customer.addCart(new Cart(number, food.getPrice(), food.getName(), food.getRestaurant()));
            return "add to cart successful";
        }

    }

    public String removeFromCard(Matcher matcher) {
        String restaurantName = matcher.group("restaurantname");
        String foodName = matcher.group("foodname");
        Restaurant restaurant = AllUsersInfo.getRestaurantByUsername(restaurantName);
        Cart food = AllUsersInfo.getCurrentCustomer().getFoodFromCartByName(foodName);

        if (restaurant == null || food == null) return "remove from cart failed: not in cart";

        if (matcher.group("number") == null) {
            food.setNumber(-1);
            if (food.getNumber() <= 0) AllUsersInfo.getCurrentCustomer().getCarts().remove(food);
            return "remove from cart successful";

        } else {
            if (Integer.parseInt(matcher.group("number")) <= 0) return "remove from cart failed: invalid number";
            int number = Integer.parseInt(matcher.group("number"));
            if (number > food.getNumber()) return "remove from cart failed: not enough food in cart";
            food.setNumber(-1 * number);
            if (food.getNumber() <= 0) AllUsersInfo.getCurrentCustomer().getCarts().remove(food);
            return "remove from cart successful";
        }

    }

    public String showCart() {
        int counter = 1;
        int totalPrice = 0;
        String result = "";
        if (!customer.getCarts().isEmpty()) {
            for (Cart temp : customer.getCarts()) {
                result += counter + ") " + temp.getName() + " | restaurant=" + temp.getRestaurant() + " price=" + (temp.getNumber() * temp.getPrice()) + "\n";
                totalPrice += temp.getNumber() * temp.getPrice();
                counter++;
            }
        }
        return result + "Total: " + totalPrice + "\n";
    }

    public String showDiscounts() {
        String result = "";
        int counter = 1;
        for (Discounts temp : customer.getDiscounts()) {
            result += counter + ") " + temp.getCode() + " | amount=" + temp.getAmount() + "\n";
            counter++;
        }
        return result;
    }

    public String payTheCart(Matcher matcher) {
        int TotalPrice = 0;
        for (Cart temp : customer.getCarts()) {
            TotalPrice += temp.getNumber() * temp.getPrice();
        }
        if (matcher.group("discount") == null) {
            if (TotalPrice > customer.getBalance()) return "purchase failed: inadequate money";
            customer.setBalance(-1 * TotalPrice);
            for (Cart temp : customer.getCarts()) {
                Restaurant restaurant = AllUsersInfo.getRestaurantByUsername(temp.getRestaurant());
                restaurant.setBalance(temp.getNumber() * temp.getPrice() - temp.getNumber() * restaurant.getFoodByName(temp.getName()).getCost());

            }
            customer.getCarts().clear();
            return "purchase successful";

        } else {
            if (customer.getDiscountByCode(matcher.group("discount")) == null)
                return "purchase failed: invalid discount code";
            int amount = customer.getDiscountByCode(matcher.group("discount")).getAmount();
            customer.setBalance(amount);
            if (TotalPrice > customer.getBalance()) {
                customer.setBalance(-1 * amount);
                return "purchase failed: inadequate money";
            }
            customer.setBalance(-1 * TotalPrice);
            for (Cart temp : customer.getCarts()) {
                Restaurant restaurant = AllUsersInfo.getRestaurantByUsername(temp.getRestaurant());
                restaurant.setBalance(temp.getNumber() * temp.getPrice() - temp.getNumber() * restaurant.getFoodByName(temp.getName()).getCost());
            }
            customer.getCarts().clear();
            int index = customer.removeWithIndex(matcher.group("discount"));
            int index1 = AllUsersInfo.removeWithIndex(matcher.group("discount"));
            if (index != -1 && index1 != -1) {
                customer.getDiscounts().remove(index);
                AllUsersInfo.getDiscounts().remove(index1);
            }

            return "purchase successful";
        }
    }

}
