import java.util.Scanner;
import java.util.regex.Matcher;

public class LoginMenu {

    public void run(Scanner scanner) {

        Matcher matcher;
        String command;




        while (true) {
            command = scanner.nextLine();

            if (command.matches("^\\s*exit\\s*$")) System.exit(0);

            else if ((matcher = Commands.getMatcher("^\\s*register\\s+(?<username>\\S+)\\s+(?<password>\\S+)\\s*$", command)) != null)
                System.out.println(register(matcher));

            else if ((matcher = Commands.getMatcher("^\\s*login\\s+(?<username>\\S+)\\s+(?<password>\\S+)\\s*$", command)) != null) {
                login(matcher);

            } else if ((matcher = Commands.getMatcher("^\\s*show\\s+current\\s+menu\\s*$", command)) != null) {
                System.out.println("login menu");
            } else if ((matcher = Commands.getMatcher("^\\s*change\\s+password\\s+(?<username>\\S+)\\s+(?<oldpassword>\\S+)\\s+(?<newpassword>\\S+)\\s*$", command)) != null) {
                System.out.println(changePassword(matcher));
            } else if ((matcher = Commands.getMatcher("^\\s*remove\\s+account\\s+(?<username>\\S+)\\s+(?<password>\\S+)\\s*$", command)) != null) {
                System.out.println(removeAccount(matcher));
            } else
                System.out.println("invalid command!");
        }

    }

    private static final Scanner scanner = new Scanner(System.in);

    public static Scanner getScanner() {
        return scanner;
    }

    public  String register(Matcher matcher) {
        String username = matcher.group("username");
        String password = matcher.group("password");
        if (!username.matches("[A-Za-z0-9_]+") || !username.matches(".*[a-zA-Z].*")) {
            return "register failed: invalid username format";

        }
        if (AllUsersInfo.getCustomerByUsername(username) != null) {
            return "register failed: username already exists";
        }
        if (!password.matches("[\\w_]+")) {
            return "register failed: invalid password format";
        } else if (!password.matches(".*[a-z].*") || !password.matches(".*[A-Z].*") ||
                !password.matches(".*[0-9].*") || password.length() < 5) {
            return "register failed: weak password";
        }

        AllUsersInfo.getCustomers().add(new Customer(username, password));
        return "register successful";
    }

    public  void login(Matcher matcher) {

        Customer customer = AllUsersInfo.getCustomerByUsername(matcher.group("username"));

        if (customer == null) {
            System.out.println("login failed: username not found");
            return;
        }
        if (!(customer.getPassword().equals(matcher.group("password")))) {

            System.out.println("login failed: incorrect password");
            return;
        }
        System.out.println("login successful");

        AllUsersInfo.setCurrentCustomer(AllUsersInfo.getCustomerByUsername(matcher.group("username")));
        MainMenu mainMenu = new MainMenu();
        mainMenu.run(LoginMenu.getScanner());

    }

    public  String changePassword(Matcher matcher) {
        Customer customer = AllUsersInfo.getCustomerByUsername(matcher.group("username"));
        String oldPassword = matcher.group("oldpassword");
        String newPassword = matcher.group("newpassword");
        String username = matcher.group("username");
        if (customer == null) {
            return "password change failed: username not found";
        }
        if (!(customer.getPassword().equals(oldPassword))) {

            return "password change failed: incorrect password";
        }
        if (!newPassword.matches("[A-Za-z0-9_]+")) {
            return "password change failed: invalid new password";
        } else if (!newPassword.matches(".*[a-z].*") || !newPassword.matches(".*[A-Z].*") ||
                !newPassword.matches(".*[0-9].*") || newPassword.length() < 5) {
            return "password change failed: weak new password";
        }
        Restaurant restaurant = AllUsersInfo.getRestaurantByUsername(username);
        customer.setPassword(newPassword);
        if (restaurant != null) restaurant.setPassword(newPassword);
        return "password change successful";

    }

    public  String removeAccount(Matcher matcher) {
        Customer customer = AllUsersInfo.getCustomerByUsername(matcher.group("username"));

        if (customer == null) {
            return "remove account failed: username not found";
        }
        if (!(customer.getPassword().equals(matcher.group("password")))) {

            return "remove account failed: incorrect password";
        }

        Restaurant restaurant = AllUsersInfo.getRestaurantByUsername(customer.getUsername());
        if(restaurant != null) {
            AllUsersInfo.getCustomers().remove(customer);
        }
        if (AllUsersInfo.getCustomers().get(0).getUsername().equals(customer.getUsername())) {
            customer.setName("-1");
            customer.setPassword("-1");
        }
        AllUsersInfo.getCustomers().remove(customer);
        return "remove account successful";

    }

}
