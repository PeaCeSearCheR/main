public class Food {
    String category;
    int price;
    String name;
    int cost;
    String restaurant;

    public Food(String category, int price, String name, int cost, String restaurant) {
        this.category = category;
        this.price = price;
        this.name = name;
        this.cost = cost;
        this.restaurant = restaurant;
    }

    public String getCategory() {
        return category;
    }

    public int getPrice() {
        return price;
    }

    public String getName() {
        return name;
    }

    public int getCost() {
        return cost;
    }

    public String getRestaurant() {
        return restaurant;
    }
}
