public class Discounts {
    String code;
    int  amount;
    Customer owner;

    public Customer getOwner() {
        return owner;
    }

    public Discounts(String code, int amount, Customer customer) {
        this.code = code;
        this.amount = amount;
        this.owner = customer;
    }

    public String getCode() {
        return code;
    }

    public int getAmount() {
        return amount;
    }
}
