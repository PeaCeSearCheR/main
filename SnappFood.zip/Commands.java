import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Commands {
    private String regex;

    Commands(String regex) {
        this.regex = regex;
    }
    public static Matcher getMatcher(String regex, String command){
        Matcher matcher = Pattern.compile(regex).matcher(command);
        return matcher.matches()? matcher : null ;
    }
}
