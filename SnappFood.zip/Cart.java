public class Cart {
    int number;
    int price;

    String name;
    String restaurant;


    int totalPrice ;
    public Cart(int number, int price, String name, String restaurant) {
        this.number = number;
        this.price = price;
        this.name = name;
        this.restaurant = restaurant;
        this.totalPrice = number * price;
    }

    public int getNumber() {
        return number;
    }

    public int getPrice() {
        return price;
    }

    public int getTotalPrice() {
        return totalPrice;
    }

    public String getName() {
        return name;
    }

    public String getRestaurant() {
        return restaurant;
    }
    public void setNumber(int number) {
        this.number += number;

    }
}
