import java.util.Scanner;
import java.util.regex.Matcher;

public class SnappfoodAdminMenu {


    public void run(Scanner scanner) {
        Matcher matcher;
        String command;
        while (true) {
            command = scanner.nextLine();

            if (command.matches("^\\s*logout\\s*$")) {
                LoginMenu loginMenu = new LoginMenu();
                loginMenu.run(scanner);
            } else if ((matcher = Commands.getMatcher("^\\s*add\\s+restaurant\\s+(?<name>\\S+)\\s+(?<password>\\S+)\\s+(?<type>\\S+)\\s*$", command)) != null)
                System.out.println(addRestaurant(matcher));
            else if ((matcher = Commands.getMatcher("^\\s*show\\s+restaurant(\\s+-t\\s+(?<type>\\S+))?\\s*$", command)) != null)
                System.out.print(showAllRestaurant(matcher));
            else if ((matcher = Commands.getMatcher("^\\s*remove\\s+restaurant\\s+((?<name>\\S+))\\s*$", command)) != null)
                System.out.print(removeRestaurant(matcher));
            else if ((matcher = Commands.getMatcher("^\\s*set\\s+discount\\s+((?<username>\\S+))\\s+(?<amount>\\S+)\\s+(?<code>\\S+)\\s*$", command)) != null)
                System.out.println(setDiscount(matcher));
            else if ((matcher = Commands.getMatcher("^\\s*show\\s+discounts\\s*$", command)) != null)
                System.out.print(showDiscounts());
            else if ((matcher = Commands.getMatcher("^\\s*show\\s+current\\s+menu\\s*$", command)) != null)
                System.out.println("Snappfood admin menu");
            else
                System.out.println("invalid command!");

        }
    }

    public static String addRestaurant(Matcher matcher) {
        String username = matcher.group("name");
        String password = matcher.group("password");
        String type = matcher.group("type");

        if (!username.matches("[\\w_]+") || !username.matches(".*[a-zA-Z].*"))
            return "add restaurant failed: invalid username format";

        if (AllUsersInfo.getCustomerByUsername(username) != null)
            return "add restaurant failed: username already exists";

        if (!password.matches("[A-Za-z0-9_]+"))
            return "add restaurant failed: invalid password format";
         else if (!password.matches(".*[a-z].*") || !password.matches(".*[A-Z].*") || !password.matches(".*[0-9].*") || password.length() < 5)
            return "add restaurant failed: weak password";

        if (!type.matches("[a-z\\-]+"))
            return "add restaurant failed: invalid type format";


        AllUsersInfo.getRestaurants().add(new Restaurant(username, type, password));
        AllUsersInfo.getCustomers().add(new Customer(username,password));
        return "add restaurant successful";

    }

    public static String showAllRestaurant(Matcher matcher) {
        String result = "";
        int counter = 1;

        if (matcher.group("type") == null) {

            for (Restaurant temp : AllUsersInfo.getRestaurants()) {

                    result += counter + ") " + temp.getName() + ": type=" + temp.getType() + " balance=" + temp.getBalance() +"\n";
                    counter++;

            }
            return result;
        } else {
            String type = matcher.group("type");
            for (Restaurant temp : AllUsersInfo.getRestaurants()) {
                if(temp.getType().equals(type)) {
                    result += counter + ") " + temp.getName() + ": type=" + temp.getType() + " balance=" + temp.getBalance() + "\n";
                    counter++;
                }
            }
            return result;
        }
    }

    public static String removeRestaurant(Matcher matcher) {
        String username = matcher.group("name");
        if (AllUsersInfo.getRestaurantByUsername(username) == null)
            return "remove restaurant failed: restaurant not found\n";
        AllUsersInfo.getRestaurants().remove(AllUsersInfo.getRestaurantByUsername(username));
        AllUsersInfo.getCustomers().remove(AllUsersInfo.getCustomerByUsername(username));
        return "";
    }

    public static String setDiscount(Matcher matcher) {
        String code = matcher.group("code");
        String username = matcher.group("username");
        String amount = matcher.group("amount");
        int parseAmount = Integer.parseInt(amount);
        Customer customer = AllUsersInfo.getCustomerByUsername(username);
        if (customer == null || AllUsersInfo.getCustomers().get(0).equals(customer)) return "set discount failed: username not found";
        if (parseAmount <= 0) {
            return "set discount failed: invalid amount";
        }
        if (!code.matches("[A-Za-z0-9]+")) return "set discount failed: invalid code format";

        customer.getDiscounts().add(new Discounts(code, parseAmount,AllUsersInfo.getCustomerByUsername(username)));
        AllUsersInfo.getDiscounts().add(new Discounts(code,parseAmount,AllUsersInfo.getCustomerByUsername(username)));
        return "set discount successful";

    }

    public static String showDiscounts() {
        String result = "";
        int counter = 1;
            for (Discounts temp : AllUsersInfo.getDiscounts()){
                result += counter + ") " + temp.getCode() + " | amount=" + temp.getAmount() + " --> user=" + temp.getOwner().getUsername() + "\n";
                counter++;
            }
        return result;
    }
}

