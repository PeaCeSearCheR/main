import java.util.Scanner;
import java.util.regex.Matcher;

public class RestaurantAdminMenu {

    public void run(Scanner scanner) {
        Matcher matcher;
        String command;
        while (true) {
            command = scanner.nextLine();

            if (command.matches("\\s*logout\\s*")) {
                LoginMenu loginMenu = new LoginMenu();
                loginMenu.run(scanner);
            } else if ((matcher = Commands.getMatcher("^\\s*charge\\s+account\\s+(?<amount>\\S+)\\s*$", command)) != null)
                System.out.println(chargeRestaurant(matcher));
            else if ((matcher = Commands.getMatcher("^\\s*show\\s+balance\\s*$", command)) != null)
                System.out.println(showBalance());
            else if ((matcher = Commands.getMatcher("^\\s*add\\s+food\\s+(?<name>\\S+)\\s+(?<category>\\S+)\\s+(?<price>\\S+)\\s+(?<cost>\\S+)\\s*$", command)) != null)
                System.out.println(addFood(matcher));
            else if ((matcher = Commands.getMatcher("^\\s*remove\\s+food\\s+(?<name>\\S+)\\s*$", command)) != null)
                System.out.print(removeFood(matcher));
            else if ((matcher = Commands.getMatcher("^\\s*show\\s+current\\s+menu\\s*$", command)) != null)
                System.out.println("restaurant admin menu");
            else System.out.println("invalid command!");

        }
    }

    public String chargeRestaurant(Matcher matcher) {
        Restaurant restaurant = AllUsersInfo.getRestaurantByUsername(AllUsersInfo.getCurrentCustomer().getUsername());
        int amount = Integer.parseInt(matcher.group("amount"));
        if (amount <= 0) return "charge account failed: invalid cost or price";
        restaurant.setBalance(amount);
        return "charge account successful";
    }

    public int showBalance() {
        return AllUsersInfo.getRestaurantByUsername(AllUsersInfo.getCurrentCustomer().getUsername()).getBalance();
    }

    public String addFood(Matcher matcher){
        String name = matcher.group("name");
        String category = matcher.group("category");
        int price = Integer.parseInt(matcher.group("price"));
        int cost = Integer.parseInt(matcher.group("cost"));

        if(!category.matches("^(dessert|entree|starter)")) return "add food failed: invalid category";
        if(!name.matches("[a-z\\-]+")) return "add food failed: invalid food name";
        if(AllUsersInfo.getRestaurantByUsername(AllUsersInfo.getCurrentCustomer().getUsername()).getFoodByName(name) != null)
            return "add food failed: food already exists";
        if(price <= 0 || cost <= 0 ) return "add food failed: invalid cost or price";

        AllUsersInfo.getRestaurantByUsername(AllUsersInfo.getCurrentCustomer().getUsername()).getFoods().add(new Food(category,price,name,cost,AllUsersInfo.getCurrentCustomer().getUsername()));
        return "add food successful";
    }

    public String removeFood(Matcher matcher){
        String name = matcher.group("name");
        Food food = AllUsersInfo.getRestaurantByUsername((AllUsersInfo.getCurrentCustomer().getUsername())).getFoodByName(name);
        if(food == null) return "remove food failed: food not found\n";
        AllUsersInfo.getRestaurantByUsername(AllUsersInfo.getCurrentCustomer().getUsername()).getFoods().remove(food);
        return "";
    }

}
