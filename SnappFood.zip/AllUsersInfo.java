import java.util.ArrayList;

public class AllUsersInfo {
    private static ArrayList<Restaurant> restaurants = new ArrayList<>();
    private static ArrayList<Customer> customers = new ArrayList<>();

    private static ArrayList<Discounts> discounts =new ArrayList<>();

    private static Customer currentCustomer;

    public static ArrayList<Discounts> getDiscounts() {
        return discounts;
    }



    public static void setCurrentCustomer(Customer customer) {
        currentCustomer = customer;
    }



    public static Customer getCustomerByUsername(String username) {
        for (Customer temp : customers) {
            if (temp.getUsername().equals(username))
                return temp;
        }
        return null;
    }
    public static ArrayList<Restaurant> getRestaurants(){
        return restaurants;
    }
    public static Restaurant getRestaurantByUsername(String username){
        for (Restaurant temp : restaurants) {
            if(temp.getName().equals(username)) return temp;
        }
        return null;
    }


    public static Customer getCurrentCustomer() {
        return currentCustomer;
    }
    public static ArrayList<Customer> getCustomers(){
        return customers;
    }
    public static int  removeWithIndex(String name) {
        for (int i = 0; i < discounts.size(); i++) {
            if (discounts.get(i).getCode().equals(name)) return i;
        }
        return -1;
    }

}
