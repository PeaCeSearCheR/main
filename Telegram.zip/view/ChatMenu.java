package view;

import controller.Messenger;
import model.*;

import java.util.Scanner;
import java.util.regex.Matcher;

public class ChatMenu {
    private Chat chat;
    private User currentUser;

    public void run(Scanner scanner, Chat userChat) {
        chat = userChat;
        currentUser = Messenger.getCurrentUser();
        Matcher matcher;
        String command;

        while (true) {
            command = scanner.nextLine();

            if ((matcher = Commands.getMatcher("^send a message c (?<message>.+)$", command)) != null)
                System.out.println(addMessage(matcher.group("message")));
            else if ((matcher = Commands.getMatcher("^add member i (?<id>\\S+)$", command)) != null)
                System.out.println(addMember(matcher, chat.getId()));

            else if ((matcher = Commands.getMatcher("^show all messages$", command)) != null)
                System.out.print((showMessages()));
            else if ((matcher = Commands.getMatcher("^show all members$", command)) != null)
                System.out.print((showMembers()));
            else if ((matcher = Commands.getMatcher("^back$", command)) != null) {
                MessengerMenu messengerMenu = new MessengerMenu();
                messengerMenu.run(scanner);
            } else System.out.println("Invalid command!");
        }
    }

    private String showMessages() {
        String result = "Messages:\n";
//        if (chat instanceof PrivateChat){
//            for (Message temp : chat.getMessages()){
//                chat
//            }
//            return result;
//        }
        for (Message temp : chat.getMessages()) {
            result += temp.getOwner().getName() + "(" + temp.getOwner().getId() + "): " + "\"" + temp.getContent() + "\"" + "\n";
        }
        return result;
    }

    private String showMembers() {
        String result = "Members:\n";
        if (chat instanceof Group || chat instanceof Channel) {
            for (User temp : chat.getMembers()) {
                if (temp.equals(chat.getOwner())) {
                    result += "name: " + temp.getName() + ", id: " + temp.getId() + " *owner\n";
                } else result += "name: " + temp.getName() + ", id: " + temp.getId() + "\n";
            }
            return result;
        } else return "Invalid command!\n";
    }

    private String addMember(Matcher matcher, String chatId) {
        String id = matcher.group("id");
        User user = Messenger.getUserById(id);
        Group group = Messenger.getGroupById(chatId);
        Channel channel = Messenger.getChannelById(chatId);
        if (chat instanceof Group) {
            if (chat.getOwner().equals(currentUser)) {
                if (user == null) {
                    return "No user with this id exists!";
                }
                if (group.getMembers().contains(user)) {
                    return "This user is already in the chat!";
                }
                group.addMembers(user);
                user.addGroup(group);
                addMessage(user.getName() + " has been added to the group!");
                return "User has been added successfully!";
            } else
                return "You don't have access to add a member!";
        } else if (chat instanceof Channel) {
            if (channel.getOwner().equals(currentUser)) {
                if (user == null) {
                    return "No user with this id exists!";
                }
                if (channel.getMembers().contains(user)) {
                    return "This user is already in the chat!";
                }
                channel.addMembers(user);
                user.addChannel(channel);

                return "User has been added successfully!";
            } else
                return "You don't have access to add a member!";
        }
        return "Invalid command!";
    }

    private String addMessage(String content) {

        if (chat instanceof Channel && !chat.getOwner().equals(currentUser))
            return "You don't have access to send a message!";
        Message message = new Message(currentUser, content);
        if (chat instanceof PrivateChat) {
            User user = Messenger.getUserById(chat.getId());
            PrivateChat current = (PrivateChat) chat;
            PrivateChat another = user.getPrivateChatById(currentUser.getId());

            if (chat.getId().equals(another.getId())) {
                currentUser.getChats().remove(current);
                currentUser.getChats().add(current);
                chat.addMessages(message);
                return "Message has been sent successfully!";
            }
            user.getChats().remove(another);
            user.addPrivateChat(another);
            currentUser.getChats().remove(current);
            currentUser.addPrivateChat(current);
            current.addMessages(message);
            another.addMessages(message);

        } else if (chat instanceof Channel) {

            for (User temp : chat.getMembers()) {
                temp.getChats().remove(chat);
                temp.addChannel((Channel) chat);
            }
            chat.addMessages(message);
        } else if (chat instanceof Group) {

            for (User temp : chat.getMembers()) {
                temp.getChats().remove(chat);
                temp.addGroup((Group) chat);
            }
            chat.addMessages(message);
        }
        return "Message has been sent successfully!";

    }
}
