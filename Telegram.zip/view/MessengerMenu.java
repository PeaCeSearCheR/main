package view;


import controller.Messenger;
import model.*;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;


public class MessengerMenu {

    private User currentUser = Messenger.getCurrentUser();
    private Chat chat = new Chat(currentUser, currentUser.getId(), currentUser.getName());

    public void run(Scanner scanner) {

        String command;
        Matcher matcher;
        while (true) {
            command = scanner.nextLine();


            if ((command.matches("logout"))) {
                System.out.println("Logged out");
                LoginMenu loginMenu = new LoginMenu();
                loginMenu.run(scanner);
            }

            if ((matcher = Commands.getMatcher("^show all channels$", command)) != null)
                System.out.print(showAllChannels());
            else if ((matcher = Commands.getMatcher("^create new channel i (?<id>\\S+) n (?<name>\\S+)$", command)) != null)
                System.out.println(createChannel(matcher));
            else if ((matcher = Commands.getMatcher("^join channel i (?<id>\\S+)$", command)) != null)
                System.out.println(joinChannel(matcher));
            else if ((matcher = Commands.getMatcher("^show my chats$", command)) != null)
                System.out.print(showChats());
            else if ((matcher = Commands.getMatcher("^create new group i (?<id>\\S+) n (?<name>\\S+)$", command)) != null)
                System.out.println(createGroup(matcher));
             else if ((matcher = Commands.getMatcher("^start a new private chat with i (?<id>\\S+)$", command)) != null)
                System.out.println(createPrivateChat(matcher));
             else if ((matcher = Commands.getMatcher("^enter (?<typeOfChat>private chat|group|channel) i (?<id>\\S+)$", command)) != null) {
                System.out.println(enterChat(matcher));
                if (enterChat(matcher).equals("You have successfully entered the chat!"))
                    ChatMenuRunner(matcher.group("typeOfChat"), matcher.group("id"));
            } else System.out.println("Invalid command!");

        }
    }

    private String showAllChannels() {
        int counter = 1;
        String result = "All channels:\n";
        if (!Messenger.getChannels().isEmpty()) {
            for (Channel temp : Messenger.getChannels()) {
                result += counter + ". " + temp.getName() + ", id: " + temp.getId() +
                        ", members: " + temp.getMembers().size() + '\n';
                counter++;
            }
        }
        return result;
    }

    private String showChats() {
        int counter = 1;
        String result = "Chats:\n";
        if (!currentUser.getChats().isEmpty()) {
            for (int i = currentUser.getChats().size()-1; i >= 0; i--) {
                if (currentUser.getChats().get(i) instanceof PrivateChat) {
                    result += counter + ". " + currentUser.getChats().get(i).getName() + ", id: " +
                            currentUser.getChats().get(i).getId() + ", private chat\n";
                } else if (currentUser.getChats().get(i) instanceof Group)
                    result += counter + ". " + currentUser.getChats().get(i).getName() + ", id: " +
                            currentUser.getChats().get(i).getId() + ", group\n";

                else if (currentUser.getChats().get(i) instanceof Channel)
                    result += counter + ". " + currentUser.getChats().get(i).getName() + ", id: " +
                            currentUser.getChats().get(i).getId() + ", channel\n";
                counter++;
            }
        }
        return result;
    }

    private String enterChat(Matcher matcher) {

        String typeOfChat = matcher.group("typeOfChat");
        String id = matcher.group("id");
        switch (typeOfChat) {
            case "group":
                if (currentUser.getGroupById(id) == null) return "You have no " + typeOfChat + " with this id!";
                else {

                    return "You have successfully entered the chat!";
                }

            case "channel":
                if (currentUser.getChannelById(id) == null) return "You have no " + typeOfChat + " with this id!";
                else {

                    return "You have successfully entered the chat!";
                }

            case "private chat":
                if (currentUser.getPrivateChatById(id) == null) return "You have no " + typeOfChat + " with this id!";

                else {

                    return "You have successfully entered the chat!";
                }
            default:
                return "Invalid command!";

        }
    }

    private String createChannel(Matcher matcher) {

        if (!matcher.group("name").matches("[a-zA-Z0-9_]+")) {
            return "Channel name's format is invalid!";

        }
        if (Messenger.getChannelById(matcher.group("id")) != null) {
            return "A channel with this id already exists!";
        }
        Channel channel = new Channel(currentUser, matcher.group("id"), matcher.group("name"));
        Messenger.getChannels().add(channel);
        currentUser.addChannel(channel);
        channel.addMembers(currentUser);
        return "Channel " + matcher.group("name") + " has been created successfully!";

    }

    private String createGroup(Matcher matcher) {

        String id = matcher.group("id");
        String name = matcher.group("name");

        if (!name.matches("[\\w_]+") && !name.matches("_")) {
            return "Group name's format is invalid!";
        }
        if (Messenger.getGroupById(id) != null) {
            return "A group with this id already exists!";
        }
        Group group = new Group(currentUser, id, name);
        currentUser.addGroup(group);
        group.addMembers(currentUser);
        Messenger.getGroups().add(group);
        return "Group " + group.getName() + " has been created successfully!";
    }

    private String createPrivateChat(Matcher matcher) {
        String id2 = matcher.group("id");

        User user2 = Messenger.getUserById(id2);

        if (currentUser.getPrivateChatById(id2) != null) {
            return "You already have a private chat with this user!";
        }
        if (user2 == null) return "No user with this id exists!";
        String name2 = Messenger.getUserById(id2).getName();
        PrivateChat privateChatAnother = new PrivateChat(user2, currentUser.getId(), currentUser.getName());
        PrivateChat privateChatCurrent = new PrivateChat(currentUser, id2 , name2);
        if (currentUser.getId().equals(id2)) {
            privateChatCurrent.addMembers(currentUser);
            currentUser.addPrivateChat(privateChatCurrent);
            return "Private chat with " + currentUser.getName() + " has been started successfully!";
        }
        privateChatCurrent.addMembers(user2);
        privateChatAnother.addMembers(currentUser);
        privateChatAnother.addMembers(user2);
        privateChatCurrent.addMembers(currentUser);
        user2.addPrivateChat((privateChatAnother));
        currentUser.addPrivateChat(privateChatCurrent);

        return "Private chat with " + privateChatCurrent.getName() + " has been started successfully!";
    }

    public String joinChannel(Matcher matcher) {
        String id = matcher.group("id");
        if (Messenger.getChannelById(id) == null) {
            return "No channel with this id exists!";
        }
        if (!Messenger.getChannelById(id).getMembers().contains(currentUser)) {
            Messenger.getChannelById(id).addMembers(currentUser);
            currentUser.addChannel(Messenger.getChannelById(id));
            return "You have successfully joined the channel!";
        } else
            return "You're already a member of this channel!";
    }

    public void ChatMenuRunner(String type, String chatId) {
        PrivateChat privateChat;
        Group group;
        Channel channel;

        switch (type) {
            case "private chat":
                privateChat = Messenger.getCurrentUser().getPrivateChatById(chatId);
                ChatMenu chatMenu = new ChatMenu();
                chatMenu.run(LoginMenu.getScanner(), privateChat);

            case "channel":
                channel = Messenger.getCurrentUser().getChannelById(chatId);
                ChatMenu chatMenu1 = new ChatMenu();
                chatMenu1.run(LoginMenu.getScanner(), channel);

            case "group":
                group = Messenger.getCurrentUser().getGroupById(chatId);
                ChatMenu chatMenu2 = new ChatMenu();
                chatMenu2.run(LoginMenu.getScanner(), group);

        }
    }
}
