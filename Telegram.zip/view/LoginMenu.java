package view;

import java.util.Scanner;
import java.util.regex.Matcher;

import controller.Messenger;
import model.Commands;
import model.Message;
import model.User;


public class LoginMenu {
        public void run(Scanner scanner) {
            Matcher matcher;
            String command;

            while (true) {
                command = scanner.nextLine();


                if (command.matches("exit")) System.exit(0);
                else if ((matcher = Commands.getMatcher("^register i (?<id>\\S+) u (?<username>\\S+) p (?<password>\\S+)$", command)) != null)
                    System.out.println(register(matcher));
                else if ((matcher = Commands.getMatcher("^login i (?<id>\\S+) p (?<password>\\S+)$", command)) != null) {
                    System.out.println(login(matcher));
                    if (login((matcher)).equals("User successfully logged in!")) {
                        User user = Messenger.getUserById(matcher.group("id"));
                        Messenger.setCurrentUser(user);
                        MessengerMenu messengerMenu = new MessengerMenu();

                            messengerMenu.run(getScanner());
                    }
                }
                else
                    System.out.println("Invalid command!");
            }

        }

        private static final Scanner scanner = new Scanner(System.in);

        public static Scanner getScanner() {
            return scanner;
        }

        public static String register(Matcher matcher) {
            String id = matcher.group("id");
            String userName = matcher.group("username");
            String password = matcher.group("password");
            if (!userName.matches("[A-Za-z0-9_]+") ) {

                return "Username's format is invalid!";

            }
            if ( (!password.matches(".*[a-z].*")) || (!password.matches(".*[A-Z].*")) || (!password.matches(".*[0-9].*")) || (!password.matches(".*[\\*\\.\\!\\@\\$\\%\\^\\&\\(\\)\\{\\}\\[\\]\\:\\;\\<\\>\\,\\?\\/\\~\\_\\+\\-\\=\\|].*"))
                    || password.length() > 32 || password.length() < 8) {
                return "Password is weak!";
            }
            if (Messenger.getUserById(id) != null) {
                return "A user with this ID already exists!";
            }
            Messenger.getUsers().add(new User(id, userName, password));
            return "User has been created successfully!";
        }

        public static String login(Matcher matcher) {

            User user = Messenger.getUserById(matcher.group("id"));

            if (user == null) {

                return "No user with this id exists!";
            }
            if (!(user.getPassword().equals(matcher.group("password")))) {

                return "Incorrect password!";
            }
                return "User successfully logged in!";

        }



}
