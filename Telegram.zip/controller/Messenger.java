package controller;

import model.Channel;
import model.Group;
import model.User;

import java.util.ArrayList;

public class Messenger {
    private static ArrayList<Channel> channels = new ArrayList<>();
    private static ArrayList<Group> groups = new ArrayList<>();
    private static ArrayList<User> users = new ArrayList<>();
    private static User currentUser;

    public static void addGroup(Group group) {
        groups.add(group);
    }

    public static void addChannel(Channel channel) {
        channels.add(channel);
    }

    public static void addUser(User user) {
       users.add(user);
    }

    public static Group getGroupById(String id) {
        for (Group temp : groups) {
            if (temp.getId().equals(id)) return temp;
        }
        return null;
    }

    public static Channel getChannelById(String id) {
        for (Channel temp : channels) {
            if (temp.getId().equals(id)) return temp;
        }
        return null;
    }

    public static User getUserById(String id) {
        for (User temp : users) {
            if (temp.getId().equals(id))
                return temp;
        }
        return null;
    }

    public static ArrayList<Channel> getChannels() {
        return channels;
    }

    public static User getCurrentUser() {
        return currentUser;
    }
    public static ArrayList<User> getUsers(){
        return users;
    }
    public static void setCurrentUser(User user){
        currentUser = user;
    }
    public static ArrayList<Group> getGroups(){
        return groups;
    }
}
