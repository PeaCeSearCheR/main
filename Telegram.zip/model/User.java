package model;

import controller.Messenger;

import java.util.ArrayList;

public class User {
    private final String id;
    private final String name;
    private final String password;
    private  ArrayList<Chat> chats;

    public User(String id, String name, String password) {

        this.id = id;
        this.name = name;
        this.password = password;
        this.chats = new ArrayList<>();
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getPassword() {
        return password;
    }

    public  ArrayList<Chat> getChats() {
        return chats;
    }

    public  void addPrivateChat(PrivateChat pv) {
        this.chats.add(pv);
    }

    public  void addChannel(Channel channel) {
    this.chats.add(channel);
    }
    public  void addGroup(Group group){
        this.chats.add(group);
    }

    public Group getGroupById(String id) {

        for (Chat temp : chats) {
            if (temp instanceof Group)
                if (temp.getId().equals(id)) {
                    return (Group) temp;
                }
        }
        return null;
    }

    public Channel getChannelById(String id) {
        for (Chat temp : chats) {
            if(temp instanceof Channel && temp.getId().equals(id)) return (Channel) temp;
        }
        return null;
    }

    public  PrivateChat getPrivateChatById(String id){
        for ( Chat temp : chats ) {
            if(temp instanceof PrivateChat && temp.getId().equals(id)){
                return (PrivateChat) temp;
            }
        }
        return null;
    }

}

