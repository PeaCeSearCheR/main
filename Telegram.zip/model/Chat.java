package model;

import java.util.ArrayList;

public class Chat {
     private ArrayList<User> members;
     private ArrayList<Message> messages;
     private User owner;
     String id;
     String name;

    public Chat(User owner, String id, String name) {
        this.owner = owner;
        this.id = id;
        this.name = name;
        this.members = new ArrayList<>();
        this.messages = new ArrayList<>();
    }


    public  ArrayList<User> getMembers() {
        return members;
    }

    public  ArrayList<Message> getMessages() {
        return messages;
    }

    public User getOwner() {
        return owner;
    }

    public void addMembers(User user) {
        this.members.add(user);
    }

    public void addMessages(Message message) {
        this.messages.add(message);
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }
}
